<?php include('nav.php') ?>
<html>

  <h1>The Sparks Bank</h1>

  
    
  
    
  

  <div class="bg">
    <div class="center">
      <ul>
        <li class="operations"><a href="users.php"><button class="btn" id="pink">View All Users</button></a></li>
        <li class="operations"><a href="transfer_money.php"><button class="btn" id="pink">Trasnfer Money</button></a></li>
        <li class="operations"><a href="transactionhistory.php"><button class="btn" id="pink">View Transfer History</button></a></li>
      </ul>
    </div>
  </div>

  <?php include('footer.php') ?>
  

</html>